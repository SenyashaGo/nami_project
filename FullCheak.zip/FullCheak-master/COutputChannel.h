#pragma once
class COutputChannel
{
public:
	COutputChannel(int newnubmer_port, bool newcheak_id, bool newcheak_msg, bool newcheak_periodicity);
	~COutputChannel();
	int nubmer_port;
	bool cheak_id;
	bool cheak_msg;
	bool cheak_periodicity;
};

