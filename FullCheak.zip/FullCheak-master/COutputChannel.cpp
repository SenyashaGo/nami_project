#include "COutputChannel.h"

COutputChannel::COutputChannel(int newnubmer_port, bool newcheak_id, bool newcheak_msg, bool newcheak_periodicity)
{
	nubmer_port = newnubmer_port;
	cheak_id = newcheak_id;
	cheak_msg = newcheak_msg;
	cheak_periodicity = newcheak_periodicity;
}

COutputChannel::~COutputChannel()
{
}
