#pragma once
class CStruk
{
public:
	int port;
	long id;
	char msg[8];
	double periodicity;
	bool port_ind;
	bool id_ind;
	bool msg_ind;
	bool periodicity_ind;
};

