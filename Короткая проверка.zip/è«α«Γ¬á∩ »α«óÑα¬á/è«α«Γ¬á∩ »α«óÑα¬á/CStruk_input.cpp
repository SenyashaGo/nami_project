#include "CStruk_input.h"
