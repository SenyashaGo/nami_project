#pragma once
class CStruk_input
{
public:
	int port;
	long id;
	char msg[8];
	double periodicity;
	bool otpravka_ind;
};

