#include "�Short_check.h"
#include <iostream>
#include <chrono>
#include <vector>
#include "CStruk.h"
#include "CStruk_input.h"
using namespace std;
vector<CStruk> book2;
vector<CStruk_input> book;
int main()
{
	�Short_check u;
	u.book2 = book2;
	u.book = book;
	u.proverka();
	system("pause");
}